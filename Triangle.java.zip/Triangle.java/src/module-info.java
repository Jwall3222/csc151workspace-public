/**
 * 
 */
/**
 * 
 */
module Triangle.java {
}