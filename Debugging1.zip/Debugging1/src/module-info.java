/**
 * 
 */
/**
 * 
 */
module Debugging1 {requires java.desktop;
}