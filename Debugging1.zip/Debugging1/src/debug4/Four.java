package debug4;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;
public class Four {
	public static void main(String[] args)
	   {
	      String costString;
	      double cost;
	      double TAX = .06;
	     DecimalFormat df= new DecimalFormat ("0.00");
	      costString = JOptionPane.showInputDialog(null,
	         "Enter price of item you are buying", "Purchases",
	         JOptionPane.INFORMATION_MESSAGE);
	      cost = Double.parseDouble(costString);
	      double result1= cost * TAX;
	      double sum= (result1 + cost);
	      JOptionPane.showMessageDialog(null, "With " + TAX * 100 +
	         "% tax,  purchase  is $" +df.format(sum));
	   }
}
