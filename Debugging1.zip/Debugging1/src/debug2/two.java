package debug2;

public class two {

	public static void main(String[] args) {

	      int a, b;
	      a = 7;
	      b = 4;
	      int sum=a+b;
	      int difference=a-b;
	      System.out.println("The sum is " +sum);
	      System.out.println("the difference is " + difference);
	      System.out.println("The product is " + a * b);

	}

}
