package debug3;

public class three {
	
	public static void main(String args[])
			   {
			      int a = 99; 
			      int b = 8;
			      int result= a%b;
			      long c = 7777777777777L;
			     
			      System.out.println("Divide " + a + " by " + b);
			      System.out.println("remainder is " +result);
			      System.out.print("c is a very large number: ");
			      System.out.println(c);
			    }

}
