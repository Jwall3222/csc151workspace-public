package random;


public class random {

	public static void main(String[] args) {
		System.out.println("Guess the number between 1 and 10");
		System.out.println("Your number here: 5"); 
		int num1 = 1+(int) (Math.random() * 10); // Generates a random number between 1 and 10
		

		System.out.println("Winning number: " + num1 );


	    }
		
	}


