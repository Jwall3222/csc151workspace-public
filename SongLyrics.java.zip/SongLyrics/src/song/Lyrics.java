package song;

public class Lyrics {

	public static void main(String[] args) {

System.out.println("All my life Ive been over the top I dont know what Im doin all I know Is I dont wanna stop all fired up im gonna go till I drop you're either in or in the way dont make me, I dont wanna stop");

	}

}
