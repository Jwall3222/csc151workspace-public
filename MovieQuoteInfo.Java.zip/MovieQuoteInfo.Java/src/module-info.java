/**
 * 
 */
/**
 * 
 */
module MovieQuoteInfo.Java {
}