package moviequoteinfo;

public class moviequoteinfo {

	public static void main(String[] args) {
	
// TODO Auto-generated method stub
          System.out.println("Movie name: Snatch");
System.out.println("First shown: 2000");


System.out.println("Policeman: So what are you doing here?");
System.out.println("Turkish: I'm taking the dog for a walk. What's the problem?");
System.out.println("Policeman: What's in the car?");
System.out.println("Turkish: Seats and a stearing wheel.");
	}

}
